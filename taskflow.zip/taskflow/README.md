# ⚡ TaskFlow — Team Task Manager

A full-stack task management app with role-based access control, Kanban boards, and real-time project tracking.

## 🚀 Live Demo
> Deploy URL goes here after Railway deployment

## ✨ Features

- **Authentication** — JWT-based signup/login with role selection (Admin/Member)
- **Role-Based Access Control** — Admins see all projects; Members see only their own
- **Project Management** — Create projects, invite members by email, set project-level roles
- **Kanban Board** — Visual task board with To Do / In Progress / Review / Done columns
- **Task Management** — Create, assign, prioritize (Low/Medium/High/Critical), set due dates
- **Dashboard** — Stats overview: total tasks, in-progress, completed, overdue, assigned to me
- **Comments** — Per-task comment threads
- **Overdue Detection** — Tasks past due date are flagged automatically

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Node.js + Express |
| Database | SQLite (better-sqlite3) |
| Auth | JWT + bcrypt |
| Frontend | React 18 + Vite |
| Routing | React Router v6 |
| HTTP | Axios |
| Deployment | Railway |

## 📁 Project Structure

```
taskflow/
├── backend/
│   ├── db/database.js       # SQLite schema & init
│   ├── middleware/auth.js   # JWT auth + RBAC middleware
│   ├── routes/
│   │   ├── auth.js          # /api/auth/*
│   │   ├── projects.js      # /api/projects/*
│   │   └── tasks.js         # /api/tasks/*
│   └── server.js            # Express app entry
├── frontend/
│   └── src/
│       ├── pages/           # Dashboard, Projects, Tasks, etc.
│       ├── components/      # Layout, shared UI
│       ├── context/         # Auth context
│       └── api.js           # Axios API layer
├── package.json             # Root build scripts
└── railway.toml             # Railway deployment config
```

## 🔌 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/signup` | Register new user |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Get current user |
| GET | `/api/auth/users` | List all users |

### Projects
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/projects` | List accessible projects |
| POST | `/api/projects` | Create project |
| GET | `/api/projects/:id` | Get project + members |
| PUT | `/api/projects/:id` | Update project |
| DELETE | `/api/projects/:id` | Delete project |
| POST | `/api/projects/:id/members` | Add member by email |
| DELETE | `/api/projects/:id/members/:userId` | Remove member |

### Tasks
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tasks` | List tasks (with filters) |
| GET | `/api/tasks/stats` | Dashboard statistics |
| POST | `/api/tasks` | Create task |
| GET | `/api/tasks/:id` | Get task + comments |
| PUT | `/api/tasks/:id` | Update task |
| DELETE | `/api/tasks/:id` | Delete task |
| POST | `/api/tasks/:id/comments` | Add comment |

## 🗃 Database Schema

- **users** — id, name, email, password (hashed), role (admin/member), avatar_color
- **projects** — id, name, description, status, owner_id
- **project_members** — project_id, user_id, role (admin/member)
- **tasks** — id, title, description, status, priority, project_id, assignee_id, reporter_id, due_date
- **comments** — id, task_id, user_id, content

## 🚢 Deploy to Railway

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo>
git push -u origin main
```

### 2. Deploy on Railway
1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Select your repository
3. Add environment variables:
   ```
   JWT_SECRET=your_random_secret_string_here
   NODE_ENV=production
   PORT=5000
   ```
4. Railway auto-detects `railway.toml` and builds/deploys
5. Copy the generated URL

### 3. (Optional) Persistent Volume
For persistent SQLite storage on Railway:
1. Add a Volume in Railway dashboard
2. Mount path: `/data`
3. Set env var: `DB_PATH=/data/taskflow.db`

## 💻 Local Development

```bash
# Install all deps
npm run install:all

# Start backend (port 5000)
npm run dev:backend

# Start frontend (port 5173) in another terminal
npm run dev:frontend
```

Frontend proxies `/api/*` to `http://localhost:5000` via Vite config.

## 🔐 Role Permissions

| Action | Admin | Project Owner | Project Admin Member | Member |
|--------|-------|---------------|---------------------|--------|
| See all projects | ✅ | — | — | — |
| Create project | ✅ | ✅ | — | — |
| Delete project | ✅ | ✅ | — | — |
| Add/remove members | ✅ | ✅ | ✅ | — |
| Create tasks | ✅ | ✅ | ✅ | ✅ |
| Edit own tasks | ✅ | ✅ | ✅ | ✅ |
| Edit any task (project) | ✅ | ✅ | ✅ | — |
| Delete task | ✅ | ✅ | — | Reporter only |
