const { getDb } = require('./database');
// Lazy proxy - getDb() returns undefined until initializeDatabase() resolves
module.exports = new Proxy({}, {
  get(_, prop) {
    const db = getDb();
    if (!db) throw new Error('Database not initialized');
    return db[prop];
  }
});
