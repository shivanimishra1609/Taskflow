const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db/db');
const { authenticate, requireProjectAccess } = require('../middleware/auth');

const router = express.Router();

// GET /api/tasks — dashboard: all tasks for user
router.get('/', authenticate, (req, res) => {
  let tasks;
  const { status, priority, project_id, assignee_id } = req.query;

  let query = `
    SELECT t.*,
      u1.name as assignee_name, u1.avatar_color as assignee_color,
      u2.name as reporter_name,
      p.name as project_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE 1=1
  `;
  const params = [];

  if (req.user.role !== 'admin') {
    query += ` AND (t.assignee_id = ? OR t.reporter_id = ? OR t.project_id IN (
      SELECT project_id FROM project_members WHERE user_id = ?
    ) OR t.project_id IN (SELECT id FROM projects WHERE owner_id = ?))`;
    params.push(req.user.id, req.user.id, req.user.id, req.user.id);
  }

  if (status) { query += ` AND t.status = ?`; params.push(status); }
  if (priority) { query += ` AND t.priority = ?`; params.push(priority); }
  if (project_id) { query += ` AND t.project_id = ?`; params.push(project_id); }
  if (assignee_id) { query += ` AND t.assignee_id = ?`; params.push(assignee_id); }

  query += ` ORDER BY
    CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
    t.due_date ASC NULLS LAST, t.created_at DESC`;

  tasks = db.prepare(query).all(...params);
  res.json({ tasks });
});

// GET /api/tasks/stats — dashboard stats
router.get('/stats', authenticate, (req, res) => {
  const userId = req.user.id;
  const isAdmin = req.user.role === 'admin';

  const baseFilter = isAdmin ? '1=1' : `(t.assignee_id = ${userId} OR t.reporter_id = ${userId} OR t.project_id IN (SELECT project_id FROM project_members WHERE user_id = ${userId}) OR t.project_id IN (SELECT id FROM projects WHERE owner_id = ${userId}))`;

  const stats = db.prepare(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN t.status = 'todo' THEN 1 ELSE 0 END) as todo,
      SUM(CASE WHEN t.status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
      SUM(CASE WHEN t.status = 'review' THEN 1 ELSE 0 END) as review,
      SUM(CASE WHEN t.status = 'done' THEN 1 ELSE 0 END) as done,
      SUM(CASE WHEN t.due_date < DATE('now') AND t.status != 'done' THEN 1 ELSE 0 END) as overdue,
      SUM(CASE WHEN t.assignee_id = ${userId} THEN 1 ELSE 0 END) as assigned_to_me
    FROM tasks t WHERE ${baseFilter}
  `).get();

  const projectStats = isAdmin
    ? db.prepare('SELECT COUNT(*) as total, SUM(CASE WHEN status = "active" THEN 1 ELSE 0 END) as active FROM projects').get()
    : db.prepare(`SELECT COUNT(*) as total, SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active FROM projects WHERE owner_id = ? OR id IN (SELECT project_id FROM project_members WHERE user_id = ?)`).get(userId, userId);

  res.json({ tasks: stats, projects: projectStats });
});

// GET /api/tasks/:id
router.get('/:id', authenticate, (req, res) => {
  const task = db.prepare(`
    SELECT t.*,
      u1.name as assignee_name, u1.email as assignee_email, u1.avatar_color as assignee_color,
      u2.name as reporter_name, u2.email as reporter_email,
      p.name as project_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE t.id = ?
  `).get(req.params.id);

  if (!task) return res.status(404).json({ error: 'Task not found' });

  const comments = db.prepare(`
    SELECT c.*, u.name as user_name, u.avatar_color FROM comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.task_id = ? ORDER BY c.created_at ASC
  `).all(req.params.id);

  res.json({ task, comments });
});

// POST /api/tasks
router.post('/', authenticate, [
  body('title').trim().isLength({ min: 2, max: 200 }),
  body('project_id').isInt(),
  body('status').optional().isIn(['todo', 'in_progress', 'review', 'done']),
  body('priority').optional().isIn(['low', 'medium', 'high', 'critical']),
  body('due_date').optional({ nullable: true }).isDate(),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { title, description, status = 'todo', priority = 'medium', project_id, assignee_id, due_date } = req.body;

  // Check project access
  const member = db.prepare('SELECT 1 FROM project_members WHERE project_id = ? AND user_id = ?').get(project_id, req.user.id);
  const project = db.prepare('SELECT owner_id FROM projects WHERE id = ?').get(project_id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  if (!member && project.owner_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Not a project member' });
  }

  const result = db.prepare(`
    INSERT INTO tasks (title, description, status, priority, project_id, assignee_id, reporter_id, due_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(title, description || null, status, priority, project_id, assignee_id || null, req.user.id, due_date || null);

  const task = db.prepare(`
    SELECT t.*, u1.name as assignee_name, u1.avatar_color as assignee_color,
      u2.name as reporter_name, p.name as project_name
    FROM tasks t LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE t.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json({ task });
});

// PUT /api/tasks/:id
router.put('/:id', authenticate, [
  body('title').optional().trim().isLength({ min: 2, max: 200 }),
  body('status').optional().isIn(['todo', 'in_progress', 'review', 'done']),
  body('priority').optional().isIn(['low', 'medium', 'high', 'critical']),
], (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const member = db.prepare('SELECT role FROM project_members WHERE project_id = ? AND user_id = ?').get(task.project_id, req.user.id);
  const project = db.prepare('SELECT owner_id FROM projects WHERE id = ?').get(task.project_id);
  const canEdit = req.user.role === 'admin' || task.reporter_id === req.user.id ||
    task.assignee_id === req.user.id || project.owner_id === req.user.id || (member && member.role === 'admin');

  if (!canEdit) return res.status(403).json({ error: 'Cannot edit this task' });

  const { title, description, status, priority, assignee_id, due_date } = req.body;

  db.prepare(`
    UPDATE tasks SET
      title = COALESCE(?, title),
      description = COALESCE(?, description),
      status = COALESCE(?, status),
      priority = COALESCE(?, priority),
      assignee_id = CASE WHEN ? IS NOT NULL THEN ? ELSE assignee_id END,
      due_date = COALESCE(?, due_date),
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(
    title || null, description || null, status || null, priority || null,
    assignee_id !== undefined ? 1 : null, assignee_id || null,
    due_date || null, req.params.id
  );

  const updated = db.prepare(`
    SELECT t.*, u1.name as assignee_name, u1.avatar_color as assignee_color,
      u2.name as reporter_name, p.name as project_name
    FROM tasks t LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id WHERE t.id = ?
  `).get(req.params.id);

  res.json({ task: updated });
});

// DELETE /api/tasks/:id
router.delete('/:id', authenticate, (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const project = db.prepare('SELECT owner_id FROM projects WHERE id = ?').get(task.project_id);
  if (task.reporter_id !== req.user.id && project.owner_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Cannot delete this task' });
  }

  db.prepare('DELETE FROM tasks WHERE id = ?').run(req.params.id);
  res.json({ message: 'Task deleted' });
});

// POST /api/tasks/:id/comments
router.post('/:id/comments', authenticate, [
  body('content').trim().isLength({ min: 1, max: 1000 }),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const result = db.prepare('INSERT INTO comments (task_id, user_id, content) VALUES (?, ?, ?)').run(req.params.id, req.user.id, req.body.content);
  const comment = db.prepare('SELECT c.*, u.name as user_name, u.avatar_color FROM comments c JOIN users u ON c.user_id = u.id WHERE c.id = ?').get(result.lastInsertRowid);

  res.status(201).json({ comment });
});

module.exports = router;
