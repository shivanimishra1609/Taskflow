import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { tasksAPI } from '../api'
import { useAuth } from '../context/AuthContext'
import { format, isPast, parseISO } from 'date-fns'

const STAT_CARDS = [
  { key: 'total', label: 'Total Tasks', color: 'var(--accent)', icon: '◎' },
  { key: 'in_progress', label: 'In Progress', color: 'var(--blue)', icon: '▷' },
  { key: 'review', label: 'In Review', color: 'var(--yellow)', icon: '◈' },
  { key: 'done', label: 'Completed', color: 'var(--green)', icon: '✓' },
]

function StatCard({ label, value, color, icon, sub }) {
  return (
    <div className="card" style={{ position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, right: 0, width: 80, height: 80, background: color, opacity: 0.06, borderRadius: '0 0 0 80px' }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: 12, color: 'var(--text2)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>{label}</div>
          <div style={{ fontSize: 32, fontFamily: 'var(--font-display)', fontWeight: 800, color }}>{value ?? '–'}</div>
          {sub && <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>{sub}</div>}
        </div>
        <div style={{ fontSize: 22, color, opacity: 0.7 }}>{icon}</div>
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { user } = useAuth()
  const [stats, setStats] = useState(null)
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([tasksAPI.stats(), tasksAPI.list({ assignee_id: user.id })]).then(([s, t]) => {
      setStats(s.data)
      setTasks(t.data.tasks.slice(0, 8))
    }).finally(() => setLoading(false))
  }, [])

  const isOverdue = (t) => t.due_date && t.status !== 'done' && isPast(parseISO(t.due_date))

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 80 }}><div className="spinner" /></div>

  return (
    <div className="animate-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Good day, {user.name.split(' ')[0]} 👋</h1>
          <p style={{ color: 'var(--text2)', marginTop: 4 }}>{format(new Date(), 'EEEE, MMMM d, yyyy')}</p>
        </div>
        <Link to="/tasks" className="btn btn-primary">+ New Task</Link>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 28 }}>
        {STAT_CARDS.map(c => (
          <StatCard key={c.key} label={c.label} value={stats?.tasks?.[c.key]} color={c.color} icon={c.icon} />
        ))}
      </div>

      {/* Secondary stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, marginBottom: 28 }}>
        <div className="card">
          <div style={{ fontSize: 12, color: 'var(--text2)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Projects</div>
          <div style={{ display: 'flex', gap: 20 }}>
            <div><div style={{ fontSize: 24, fontFamily: 'var(--font-display)', fontWeight: 800 }}>{stats?.projects?.total ?? 0}</div><div style={{ fontSize: 11, color: 'var(--text3)' }}>Total</div></div>
            <div><div style={{ fontSize: 24, fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--green)' }}>{stats?.projects?.active ?? 0}</div><div style={{ fontSize: 11, color: 'var(--text3)' }}>Active</div></div>
          </div>
        </div>
        <div className="card">
          <div style={{ fontSize: 12, color: 'var(--text2)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Assigned to Me</div>
          <div style={{ fontSize: 24, fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--accent)' }}>{stats?.tasks?.assigned_to_me ?? 0}</div>
          <div style={{ fontSize: 11, color: 'var(--text3)' }}>tasks pending</div>
        </div>
        <div className="card">
          <div style={{ fontSize: 12, color: 'var(--text2)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Overdue</div>
          <div style={{ fontSize: 24, fontFamily: 'var(--font-display)', fontWeight: 800, color: stats?.tasks?.overdue > 0 ? 'var(--red)' : 'var(--text)' }}>{stats?.tasks?.overdue ?? 0}</div>
          <div style={{ fontSize: 11, color: 'var(--text3)' }}>{stats?.tasks?.overdue > 0 ? 'need attention' : 'all on track ✓'}</div>
        </div>
      </div>

      {/* Recent Tasks */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700 }}>My Tasks</h2>
          <Link to="/tasks" style={{ fontSize: 12, color: 'var(--accent)' }}>View all →</Link>
        </div>
        {tasks.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">◎</div>
            <div className="empty-state-text">No tasks yet</div>
            <div className="empty-state-sub">Create a project and add some tasks!</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {tasks.map(t => (
              <Link key={t.id} to={`/tasks/${t.id}`} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '10px 12px', background: 'var(--bg3)', borderRadius: 8,
                border: '1px solid var(--border)', transition: 'all 0.15s',
                textDecoration: 'none'
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--border2)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
              >
                <span className={`badge tag-${t.status}`}>{t.status.replace('_',' ')}</span>
                <span style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{t.title}</span>
                <span style={{ fontSize: 11, color: 'var(--text3)' }}>{t.project_name}</span>
                <span className={`badge tag-${t.priority}`}>{t.priority}</span>
                {isOverdue(t) && <span className="badge tag-overdue">overdue</span>}
                {t.due_date && <span style={{ fontSize: 11, color: isOverdue(t) ? 'var(--red)' : 'var(--text3)' }}>{format(parseISO(t.due_date), 'MMM d')}</span>}
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
