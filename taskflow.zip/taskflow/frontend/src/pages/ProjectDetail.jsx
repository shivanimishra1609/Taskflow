import { useState, useEffect } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { projectsAPI, tasksAPI, authAPI } from '../api'
import { useAuth } from '../context/AuthContext'
import { format, isPast, parseISO } from 'date-fns'

function AddMemberModal({ projectId, onClose, onAdd }) {
  const [email, setEmail] = useState('')
  const [role, setRole] = useState('member')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('')
    try {
      const res = await projectsAPI.addMember(projectId, { email, role })
      onAdd(res.data.member); onClose()
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to add member')
    } finally { setLoading(false) }
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <h3 className="modal-title">Add Team Member</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">User Email</label>
            <input className="input-field" type="email" placeholder="member@example.com"
              value={email} onChange={e => setEmail(e.target.value)} required />
          </div>
          <div className="form-group">
            <label className="form-label">Project Role</label>
            <select className="input-field" value={role} onChange={e => setRole(e.target.value)}>
              <option value="member">Member</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          {error && <p className="error-msg" style={{ marginBottom: 12 }}>{error}</p>}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary" disabled={loading}>{loading ? 'Adding…' : 'Add Member'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}

function CreateTaskModal({ projectId, members, onClose, onSave }) {
  const { user } = useAuth()
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', status: 'todo', assignee_id: '', due_date: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('')
    try {
      const payload = { ...form, project_id: parseInt(projectId), assignee_id: form.assignee_id ? parseInt(form.assignee_id) : undefined }
      const res = await tasksAPI.create(payload)
      onSave(res.data.task); onClose()
    } catch (err) {
      setError(err.response?.data?.errors?.[0]?.msg || 'Failed to create task')
    } finally { setLoading(false) }
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <h3 className="modal-title">New Task</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Title *</label>
            <input className="input-field" placeholder="Task title" value={form.title}
              onChange={e => setForm({...form, title: e.target.value})} required />
          </div>
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea className="input-field" rows={3} placeholder="Details…" style={{ resize: 'none' }}
              value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Priority</label>
              <select className="input-field" value={form.priority} onChange={e => setForm({...form, priority: e.target.value})}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Status</label>
              <select className="input-field" value={form.status} onChange={e => setForm({...form, status: e.target.value})}>
                <option value="todo">To Do</option>
                <option value="in_progress">In Progress</option>
                <option value="review">Review</option>
                <option value="done">Done</option>
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Assignee</label>
              <select className="input-field" value={form.assignee_id} onChange={e => setForm({...form, assignee_id: e.target.value})}>
                <option value="">Unassigned</option>
                {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Due Date</label>
              <input className="input-field" type="date" value={form.due_date} onChange={e => setForm({...form, due_date: e.target.value})} />
            </div>
          </div>
          {error && <p className="error-msg" style={{ marginBottom: 12 }}>{error}</p>}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary" disabled={loading}>{loading ? 'Creating…' : 'Create Task'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}

const STATUS_COLS = ['todo', 'in_progress', 'review', 'done']
const STATUS_LABELS = { todo: 'To Do', in_progress: 'In Progress', review: 'Review', done: 'Done' }

export default function ProjectDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [project, setProject] = useState(null)
  const [members, setMembers] = useState([])
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [showAddMember, setShowAddMember] = useState(false)
  const [showCreateTask, setShowCreateTask] = useState(false)
  const [activeTab, setActiveTab] = useState('board')

  useEffect(() => {
    Promise.all([
      projectsAPI.get(id),
      tasksAPI.list({ project_id: id })
    ]).then(([p, t]) => {
      setProject(p.data.project)
      setMembers(p.data.members)
      setTasks(t.data.tasks)
    }).catch(() => navigate('/projects'))
    .finally(() => setLoading(false))
  }, [id])

  const handleDeleteProject = async () => {
    if (!confirm('Delete this project and all its tasks?')) return
    await projectsAPI.delete(id)
    navigate('/projects')
  }

  const handleRemoveMember = async (userId) => {
    if (!confirm('Remove this member?')) return
    await projectsAPI.removeMember(id, userId)
    setMembers(members.filter(m => m.id !== userId))
  }

  const isOwner = project?.owner_id === user.id
  const isAdmin = user.role === 'admin'
  const canManage = isOwner || isAdmin

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 80 }}><div className="spinner" /></div>
  if (!project) return null

  const tasksByStatus = STATUS_COLS.reduce((acc, s) => {
    acc[s] = tasks.filter(t => t.status === s)
    return acc
  }, {})

  return (
    <div className="animate-in">
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <Link to="/projects" style={{ fontSize: 13, color: 'var(--text3)' }}>Projects</Link>
          <span style={{ color: 'var(--text3)' }}>/</span>
          <span style={{ fontSize: 13, color: 'var(--text2)' }}>{project.name}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div>
            <h1 style={{ fontSize: 26, fontFamily: 'var(--font-display)', fontWeight: 800 }}>{project.name}</h1>
            {project.description && <p style={{ color: 'var(--text2)', marginTop: 4 }}>{project.description}</p>}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-primary btn-sm" onClick={() => setShowCreateTask(true)}>+ Task</button>
            <button className="btn btn-ghost btn-sm" onClick={() => setShowAddMember(true)}>+ Member</button>
            {canManage && <button className="btn btn-danger btn-sm" onClick={handleDeleteProject}>Delete</button>}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1px solid var(--border)', paddingBottom: 0 }}>
        {['board', 'members'].map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} style={{
            padding: '8px 16px', background: 'none', borderRadius: '6px 6px 0 0',
            color: activeTab === tab ? 'var(--accent)' : 'var(--text2)',
            borderBottom: activeTab === tab ? '2px solid var(--accent)' : '2px solid transparent',
            fontWeight: activeTab === tab ? 600 : 400,
            fontSize: 13, textTransform: 'capitalize', marginBottom: -1
          }}>{tab}</button>
        ))}
      </div>

      {/* Board View */}
      {activeTab === 'board' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {STATUS_COLS.map(status => (
            <div key={status} style={{ background: 'var(--bg2)', borderRadius: 10, padding: 12, border: '1px solid var(--border)', minHeight: 200 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <span style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text2)' }}>{STATUS_LABELS[status]}</span>
                <span style={{ fontSize: 11, background: 'var(--bg4)', padding: '2px 8px', borderRadius: 10, color: 'var(--text3)' }}>{tasksByStatus[status].length}</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {tasksByStatus[status].map(t => (
                  <Link key={t.id} to={`/tasks/${t.id}`} style={{ textDecoration: 'none' }}>
                    <div style={{
                      background: 'var(--bg3)', borderRadius: 8, padding: '10px 12px',
                      border: '1px solid var(--border)', cursor: 'pointer', transition: 'all 0.15s'
                    }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
                    onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
                    >
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8, lineHeight: 1.4 }}>{t.title}</div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span className={`badge tag-${t.priority}`}>{t.priority}</span>
                        {t.assignee_name && (
                          <div className="avatar avatar-sm" style={{ background: t.assignee_color }} title={t.assignee_name}>
                            {t.assignee_name[0].toUpperCase()}
                          </div>
                        )}
                      </div>
                      {t.due_date && (
                        <div style={{ fontSize: 11, color: isPast(parseISO(t.due_date)) && t.status !== 'done' ? 'var(--red)' : 'var(--text3)', marginTop: 6 }}>
                          Due {format(parseISO(t.due_date), 'MMM d')}
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Members View */}
      {activeTab === 'members' && (
        <div className="card">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {members.map(m => (
              <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <div className="avatar avatar-md" style={{ background: m.avatar_color }}>{m.name[0].toUpperCase()}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{m.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text3)' }}>{m.email}</div>
                </div>
                <span className="badge" style={{ background: 'var(--bg4)', color: 'var(--text2)', textTransform: 'capitalize' }}>{m.project_role}</span>
                <span className="badge" style={{ background: m.user_role === 'admin' ? 'rgba(124,111,255,0.15)' : 'var(--bg4)', color: m.user_role === 'admin' ? 'var(--accent)' : 'var(--text3)' }}>{m.user_role}</span>
                {canManage && m.id !== project.owner_id && (
                  <button className="btn btn-danger btn-sm" onClick={() => handleRemoveMember(m.id)}>Remove</button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {showAddMember && <AddMemberModal projectId={id} onClose={() => setShowAddMember(false)} onAdd={m => setMembers([...members, m])} />}
      {showCreateTask && <CreateTaskModal projectId={id} members={members} onClose={() => setShowCreateTask(false)} onSave={t => setTasks([t, ...tasks])} />}
    </div>
  )
}
