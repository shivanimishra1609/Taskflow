import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { projectsAPI } from '../api'
import { useAuth } from '../context/AuthContext'

function ProjectModal({ onClose, onSave }) {
  const [form, setForm] = useState({ name: '', description: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true)
    try {
      const res = await projectsAPI.create(form)
      onSave(res.data.project); onClose()
    } catch (err) {
      setError(err.response?.data?.errors?.[0]?.msg || 'Failed to create project')
    } finally { setLoading(false) }
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <h3 className="modal-title">New Project</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Project Name *</label>
            <input className="input-field" placeholder="e.g. Website Redesign" value={form.name}
              onChange={e => setForm({...form, name: e.target.value})} required minLength={2} />
          </div>
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea className="input-field" rows={3} placeholder="What is this project about?"
              value={form.description} onChange={e => setForm({...form, description: e.target.value})}
              style={{ resize: 'none' }} />
          </div>
          {error && <p className="error-msg" style={{ marginBottom: 12 }}>{error}</p>}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary" disabled={loading}>{loading ? 'Creating…' : 'Create Project'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}

const STATUS_COLORS = { active: 'var(--green)', archived: 'var(--text3)', completed: 'var(--accent)' }

export default function Projects() {
  const { user } = useAuth()
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    projectsAPI.list().then(res => setProjects(res.data.projects)).finally(() => setLoading(false))
  }, [])

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 80 }}><div className="spinner" /></div>

  return (
    <div className="animate-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Projects</h1>
          <p style={{ color: 'var(--text2)', marginTop: 4 }}>{projects.length} project{projects.length !== 1 ? 's' : ''}</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Project</button>
      </div>

      {projects.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <div className="empty-state-icon">◈</div>
            <div className="empty-state-text">No projects yet</div>
            <div className="empty-state-sub">Create your first project to get started</div>
            <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => setShowModal(true)}>Create Project</button>
          </div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
          {projects.map(p => {
            const progress = p.task_count > 0 ? Math.round((p.done_count / p.task_count) * 100) : 0
            return (
              <Link key={p.id} to={`/projects/${p.id}`} style={{ textDecoration: 'none' }}>
                <div className="card" style={{ cursor: 'pointer', transition: 'all 0.15s', height: '100%' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--border2)'; e.currentTarget.style.transform = 'translateY(-2px)' }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = '' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                    <h3 style={{ fontSize: 15, fontWeight: 700, flex: 1, marginRight: 8 }}>{p.name}</h3>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: STATUS_COLORS[p.status], flexShrink: 0, marginTop: 5 }} />
                  </div>
                  {p.description && <p style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 14, lineHeight: 1.5 }}>{p.description.slice(0, 80)}{p.description.length > 80 ? '…' : ''}</p>}
                  <div style={{ marginBottom: 14 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ fontSize: 11, color: 'var(--text3)' }}>Progress</span>
                      <span style={{ fontSize: 11, color: 'var(--text2)', fontWeight: 600 }}>{progress}%</span>
                    </div>
                    <div className="progress-bar"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>
                  </div>
                  <div style={{ display: 'flex', gap: 16 }}>
                    <span style={{ fontSize: 12, color: 'var(--text3)' }}>📋 {p.task_count} tasks</span>
                    <span style={{ fontSize: 12, color: 'var(--text3)' }}>👥 {p.member_count} members</span>
                    <span style={{ fontSize: 12, color: 'var(--text3)', textTransform: 'capitalize' }}>{p.status}</span>
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      )}

      {showModal && <ProjectModal onClose={() => setShowModal(false)} onSave={p => setProjects([p, ...projects])} />}
    </div>
  )
}
