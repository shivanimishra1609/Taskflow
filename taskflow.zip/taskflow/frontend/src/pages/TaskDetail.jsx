import { useState, useEffect } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { tasksAPI, authAPI } from '../api'
import { useAuth } from '../context/AuthContext'
import { format, isPast, parseISO } from 'date-fns'

export default function TaskDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [task, setTask] = useState(null)
  const [comments, setComments] = useState([])
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [editForm, setEditForm] = useState({})
  const [comment, setComment] = useState('')
  const [saving, setSaving] = useState(false)
  const [commentLoading, setCommentLoading] = useState(false)

  useEffect(() => {
    Promise.all([tasksAPI.get(id), authAPI.users()]).then(([t, u]) => {
      setTask(t.data.task)
      setComments(t.data.comments)
      setUsers(u.data.users)
      setEditForm({
        title: t.data.task.title,
        description: t.data.task.description || '',
        status: t.data.task.status,
        priority: t.data.task.priority,
        assignee_id: t.data.task.assignee_id || '',
        due_date: t.data.task.due_date || '',
      })
    }).catch(() => navigate('/tasks'))
    .finally(() => setLoading(false))
  }, [id])

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = { ...editForm, assignee_id: editForm.assignee_id ? parseInt(editForm.assignee_id) : null }
      const res = await tasksAPI.update(id, payload)
      setTask(res.data.task)
      setEditing(false)
    } finally { setSaving(false) }
  }

  const handleStatusChange = async (status) => {
    const res = await tasksAPI.update(id, { status })
    setTask(res.data.task)
  }

  const handleDelete = async () => {
    if (!confirm('Delete this task?')) return
    await tasksAPI.delete(id)
    navigate('/tasks')
  }

  const handleComment = async (e) => {
    e.preventDefault()
    if (!comment.trim()) return
    setCommentLoading(true)
    try {
      const res = await tasksAPI.addComment(id, { content: comment })
      setComments([...comments, res.data.comment])
      setComment('')
    } finally { setCommentLoading(false) }
  }

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 80 }}><div className="spinner" /></div>
  if (!task) return null

  const isOverdue = task.due_date && task.status !== 'done' && isPast(parseISO(task.due_date))

  return (
    <div className="animate-in" style={{ maxWidth: 900 }}>
      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
        <Link to="/tasks" style={{ fontSize: 13, color: 'var(--text3)' }}>Tasks</Link>
        <span style={{ color: 'var(--text3)' }}>/</span>
        <span style={{ fontSize: 13, color: 'var(--text2)' }}>#{task.id}</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 20 }}>
        {/* Main */}
        <div>
          <div className="card" style={{ marginBottom: 16 }}>
            {editing ? (
              <div>
                <div className="form-group">
                  <input className="input-field" value={editForm.title}
                    onChange={e => setEditForm({...editForm, title: e.target.value})}
                    style={{ fontSize: 18, fontWeight: 700, fontFamily: 'var(--font-display)' }} />
                </div>
                <div className="form-group">
                  <label className="form-label">Description</label>
                  <textarea className="input-field" rows={4} style={{ resize: 'vertical' }}
                    value={editForm.description} onChange={e => setEditForm({...editForm, description: e.target.value})} />
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-primary" onClick={handleSave} disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
                  <button className="btn btn-ghost" onClick={() => setEditing(false)}>Cancel</button>
                </div>
              </div>
            ) : (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <h1 style={{ fontSize: 22, fontFamily: 'var(--font-display)', fontWeight: 800, flex: 1, marginRight: 12 }}>{task.title}</h1>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => setEditing(true)}>Edit</button>
                    <button className="btn btn-danger btn-sm" onClick={handleDelete}>Delete</button>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
                  <span className={`badge tag-${task.status}`}>{task.status.replace('_',' ')}</span>
                  <span className={`badge tag-${task.priority}`}>{task.priority}</span>
                  {isOverdue && <span className="badge tag-overdue">overdue</span>}
                </div>
                {task.description ? (
                  <p style={{ color: 'var(--text2)', lineHeight: 1.7, fontSize: 14 }}>{task.description}</p>
                ) : (
                  <p style={{ color: 'var(--text3)', fontStyle: 'italic', fontSize: 13 }}>No description</p>
                )}
              </div>
            )}
          </div>

          {/* Quick Status */}
          <div className="card" style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text2)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 10 }}>Change Status</div>
            <div style={{ display: 'flex', gap: 6 }}>
              {['todo', 'in_progress', 'review', 'done'].map(s => (
                <button key={s} onClick={() => handleStatusChange(s)} style={{
                  padding: '6px 12px', borderRadius: 6, fontSize: 12, fontWeight: 500,
                  background: task.status === s ? 'var(--accent)' : 'var(--bg3)',
                  color: task.status === s ? 'white' : 'var(--text2)',
                  border: `1px solid ${task.status === s ? 'var(--accent)' : 'var(--border)'}`,
                  cursor: 'pointer', transition: 'all 0.15s'
                }}>{s.replace('_', ' ')}</button>
              ))}
            </div>
          </div>

          {/* Comments */}
          <div className="card">
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text2)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>
              Comments ({comments.length})
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 16 }}>
              {comments.map(c => (
                <div key={c.id} style={{ display: 'flex', gap: 10 }}>
                  <div className="avatar avatar-sm" style={{ background: c.avatar_color, flexShrink: 0 }}>{c.user_name[0].toUpperCase()}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'baseline', marginBottom: 4 }}>
                      <span style={{ fontSize: 13, fontWeight: 600 }}>{c.user_name}</span>
                      <span style={{ fontSize: 11, color: 'var(--text3)' }}>{format(new Date(c.created_at), 'MMM d, h:mm a')}</span>
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.6, background: 'var(--bg3)', padding: '8px 12px', borderRadius: 8 }}>{c.content}</div>
                  </div>
                </div>
              ))}
              {comments.length === 0 && <p style={{ fontSize: 13, color: 'var(--text3)', fontStyle: 'italic' }}>No comments yet</p>}
            </div>
            <form onSubmit={handleComment} style={{ display: 'flex', gap: 8 }}>
              <input className="input-field" placeholder="Write a comment…" style={{ flex: 1 }}
                value={comment} onChange={e => setComment(e.target.value)} />
              <button className="btn btn-primary" disabled={commentLoading || !comment.trim()}>Post</button>
            </form>
          </div>
        </div>

        {/* Sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="card">
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>Details</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>Project</div>
                <Link to={`/projects/${task.project_id}`} style={{ fontSize: 13, color: 'var(--accent)' }}>{task.project_name}</Link>
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 6 }}>Assignee</div>
                {editing ? (
                  <select className="input-field" style={{ fontSize: 12 }} value={editForm.assignee_id} onChange={e => setEditForm({...editForm, assignee_id: e.target.value})}>
                    <option value="">Unassigned</option>
                    {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                ) : task.assignee_name ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div className="avatar avatar-sm" style={{ background: task.assignee_color }}>{task.assignee_name[0].toUpperCase()}</div>
                    <span style={{ fontSize: 13 }}>{task.assignee_name}</span>
                  </div>
                ) : <span style={{ fontSize: 13, color: 'var(--text3)' }}>Unassigned</span>}
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>Reporter</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 13 }}>{task.reporter_name}</span>
                </div>
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 6 }}>Due Date</div>
                {editing ? (
                  <input className="input-field" type="date" style={{ fontSize: 12 }} value={editForm.due_date} onChange={e => setEditForm({...editForm, due_date: e.target.value})} />
                ) : (
                  <span style={{ fontSize: 13, color: isOverdue ? 'var(--red)' : 'var(--text)' }}>
                    {task.due_date ? format(parseISO(task.due_date), 'MMM d, yyyy') : '—'}
                  </span>
                )}
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>Priority</div>
                {editing ? (
                  <select className="input-field" style={{ fontSize: 12 }} value={editForm.priority} onChange={e => setEditForm({...editForm, priority: e.target.value})}>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="critical">Critical</option>
                  </select>
                ) : <span className={`badge tag-${task.priority}`}>{task.priority}</span>}
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>Created</div>
                <span style={{ fontSize: 12, color: 'var(--text2)' }}>{format(new Date(task.created_at), 'MMM d, yyyy')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
