import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { tasksAPI, projectsAPI, authAPI } from '../api'
import { useAuth } from '../context/AuthContext'
import { format, isPast, parseISO } from 'date-fns'

function CreateTaskModal({ onClose, onSave }) {
  const { user } = useAuth()
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', status: 'todo', project_id: '', assignee_id: '', due_date: '' })
  const [projects, setProjects] = useState([])
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    projectsAPI.list().then(res => setProjects(res.data.projects.filter(p => p.status === 'active')))
    authAPI.users().then(res => setMembers(res.data.users))
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('')
    try {
      const payload = { ...form, project_id: parseInt(form.project_id), assignee_id: form.assignee_id ? parseInt(form.assignee_id) : undefined }
      const res = await tasksAPI.create(payload)
      onSave(res.data.task); onClose()
    } catch (err) {
      setError(err.response?.data?.errors?.[0]?.msg || err.response?.data?.error || 'Failed to create task')
    } finally { setLoading(false) }
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <h3 className="modal-title">New Task</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Title *</label>
            <input className="input-field" placeholder="Task title" value={form.title}
              onChange={e => setForm({...form, title: e.target.value})} required />
          </div>
          <div className="form-group">
            <label className="form-label">Project *</label>
            <select className="input-field" value={form.project_id} onChange={e => setForm({...form, project_id: e.target.value})} required>
              <option value="">Select project…</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea className="input-field" rows={2} style={{ resize: 'none' }}
              value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Priority</label>
              <select className="input-field" value={form.priority} onChange={e => setForm({...form, priority: e.target.value})}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Status</label>
              <select className="input-field" value={form.status} onChange={e => setForm({...form, status: e.target.value})}>
                <option value="todo">To Do</option>
                <option value="in_progress">In Progress</option>
                <option value="review">Review</option>
                <option value="done">Done</option>
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Assignee</label>
              <select className="input-field" value={form.assignee_id} onChange={e => setForm({...form, assignee_id: e.target.value})}>
                <option value="">Unassigned</option>
                {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Due Date</label>
              <input className="input-field" type="date" value={form.due_date} onChange={e => setForm({...form, due_date: e.target.value})} />
            </div>
          </div>
          {error && <p className="error-msg" style={{ marginBottom: 12 }}>{error}</p>}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary" disabled={loading}>{loading ? 'Creating…' : 'Create Task'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function Tasks() {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [filters, setFilters] = useState({ status: '', priority: '' })

  const fetchTasks = () => {
    setLoading(true)
    tasksAPI.list(filters).then(res => setTasks(res.data.tasks)).finally(() => setLoading(false))
  }

  useEffect(() => { fetchTasks() }, [filters])

  const isOverdue = (t) => t.due_date && t.status !== 'done' && isPast(parseISO(t.due_date))

  return (
    <div className="animate-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Tasks</h1>
          <p style={{ color: 'var(--text2)', marginTop: 4 }}>{tasks.length} task{tasks.length !== 1 ? 's' : ''}</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Task</button>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
        <select className="input-field" style={{ width: 140 }} value={filters.status} onChange={e => setFilters({...filters, status: e.target.value})}>
          <option value="">All Status</option>
          <option value="todo">To Do</option>
          <option value="in_progress">In Progress</option>
          <option value="review">Review</option>
          <option value="done">Done</option>
        </select>
        <select className="input-field" style={{ width: 140 }} value={filters.priority} onChange={e => setFilters({...filters, priority: e.target.value})}>
          <option value="">All Priority</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
          <option value="critical">Critical</option>
        </select>
        {(filters.status || filters.priority) && (
          <button className="btn btn-ghost" onClick={() => setFilters({ status: '', priority: '' })}>Clear</button>
        )}
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 40 }}><div className="spinner" /></div>
      ) : tasks.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <div className="empty-state-icon">◎</div>
            <div className="empty-state-text">No tasks found</div>
            <div className="empty-state-sub">Create a task or adjust your filters</div>
          </div>
        </div>
      ) : (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Task', 'Project', 'Assignee', 'Priority', 'Status', 'Due Date'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tasks.map(t => (
                <tr key={t.id} style={{ borderBottom: '1px solid var(--border)', transition: 'background 0.1s', cursor: 'pointer' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg3)'}
                  onMouseLeave={e => e.currentTarget.style.background = ''}
                  onClick={() => window.location.href = `/tasks/${t.id}`}
                >
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ fontWeight: 500, fontSize: 13 }}>{t.title}</div>
                    {isOverdue(t) && <span className="badge tag-overdue" style={{ marginTop: 4 }}>overdue</span>}
                  </td>
                  <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text2)' }}>
                    <Link to={`/projects/${t.project_id}`} onClick={e => e.stopPropagation()} style={{ color: 'var(--accent)' }}>{t.project_name}</Link>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    {t.assignee_name ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div className="avatar avatar-sm" style={{ background: t.assignee_color }}>{t.assignee_name[0].toUpperCase()}</div>
                        <span style={{ fontSize: 12, color: 'var(--text2)' }}>{t.assignee_name}</span>
                      </div>
                    ) : <span style={{ fontSize: 12, color: 'var(--text3)' }}>Unassigned</span>}
                  </td>
                  <td style={{ padding: '12px 16px' }}><span className={`badge tag-${t.priority}`}>{t.priority}</span></td>
                  <td style={{ padding: '12px 16px' }}><span className={`badge tag-${t.status}`}>{t.status.replace('_',' ')}</span></td>
                  <td style={{ padding: '12px 16px', fontSize: 12, color: isOverdue(t) ? 'var(--red)' : 'var(--text3)' }}>
                    {t.due_date ? format(parseISO(t.due_date), 'MMM d, yyyy') : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && <CreateTaskModal onClose={() => setShowModal(false)} onSave={t => { setTasks([t, ...tasks]); }} />}
    </div>
  )
}
